//
//  NPStyle.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-04-29.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

// Order of priority:
//     - Class
//     - Context
//     - States (in order of addition)
@interface NPStyle : NSObject
- (id)valueForAttribute:(NSString *)attribute;
- (id)objectForKeyedSubscript:(id)key;

- (NSDictionary *)attributeValues;

- (NSArray *)debugEntries; // For debugging only!

@end

@class NPClassSheet;
@class NPStyleStateValue;

@interface NPStyle()
- (id)initWithClassSheet:(NPClassSheet *)classSheet context:(NSString *)context state:(NPStyleStateValue *)state;

@property (nonatomic, unsafe_unretained, readonly) NPStyleSheet *styleSheet;
@property (nonatomic, unsafe_unretained, readonly) Class styleClass;

@property (nonatomic, unsafe_unretained, readonly) NPClassSheet *classSheet;
@property (nonatomic, strong, readonly) NSString *context;
@property (nonatomic, strong, readonly) NPStyleStateValue *state;

- (void)clearValues;

@end
