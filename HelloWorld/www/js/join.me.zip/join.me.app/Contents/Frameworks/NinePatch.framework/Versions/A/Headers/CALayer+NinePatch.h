//
//  CALayer+NinePatch.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-10-06.
//  Copyright (c) 2011 LogMeIn, Inc. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <ninepatch/NPNinePatch.h>

@interface CALayer (NinePatch)
// Sets the layer contents to the supplied nine patch image, and sets up contentsCenter so that it resizes according to 9patch rules.
// Does not support tiled 9patch images.
- (void)setContentsToNinePatch:(NPNinePatch *)ninePatch;

@property CGFloat npContentsScale; // Wrapper for contentsScale that works on OS X 10.6 / iOS 3.x

@end
