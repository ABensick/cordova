//
//  NSWindow+NinePatch.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2011-06-14.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPUtil.h>

@interface NSWindow (NinePatch)
@property (nonatomic, readonly) CGFloat npBackingScaleFactor;
@property (nonatomic, assign) NSWindowAnimationBehavior npAnimationBehavior;

@property (nonatomic, assign) NSRect contentRect;
- (void)setContentRect:(NSRect)contentRect display:(BOOL)display;

- (NPEdgeInsets)contentInsets;

- (NSRect)visualFrame;
- (NPEdgeInsets)visualInsets;
- (void)setVisualFrame:(NSRect)frame;

- (NSSize)visualMinSize;
- (void)setVisualMinSize:(NSSize)size;

- (NSSize)visualMaxSize;
- (void)setVisualMaxSize:(NSSize)size;

- (void)setVisualLocation:(NSPoint)location ofAnchor:(NPPatch)anchor;

- (NSRect)visualFrameForContentRect:(NSRect)contentRect;
- (NSRect)contentRectForVisualFrame:(NSRect)visualFrame;

- (NSRect)npConvertRectToScreen:(NSRect)baseRect;
- (NSRect)npConvertRectFromScreen:(NSRect)screenRect;

- (NSRect)npConvertViewFrameToScreen:(NSView *)view;


@end
