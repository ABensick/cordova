//
//  NPButtonCell.h
//  ninepatch
//
//  Created by Tamas Domonkos on 4/30/11.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPNinePatch.h>

// A fully configurable button cell with a nine patch background.
@interface NPButtonCell : NSButtonCell 

@property (nonatomic, strong) NSColor *textColor;
@property (nonatomic, strong) NSColor *alternateTextColor;
@property (nonatomic, strong) NSColor *hoverTextColor;
@property (nonatomic, strong) NSColor *pressedTextColor;
@property (nonatomic, strong) NSColor *disabledTextColor;
@property (nonatomic, assign) CGFloat textOffset; // Hack
@property (nonatomic, assign) CGFloat imageOffset;

@property (nonatomic, strong) NPNinePatch *background;
@property (nonatomic, strong) NPNinePatch *highlightedBackground;
@property (nonatomic, strong) NPNinePatch *hoverBackground;
@property (nonatomic, strong) NPNinePatch *disabledBackground;
@property (nonatomic, assign) NPEdgeInsets contentInsets;

@property (nonatomic, strong) NSImage *image; // Redeclared as a property from NSButtonCell
@property (nonatomic, strong) NSImage *alternateImage; // Redeclared as a property from NSButtonCell
@property (nonatomic, strong) NSImage *hoverImage;
@property (nonatomic, strong) NSImage *hoverAlternateImage;
@property (nonatomic, strong) NSImage *pressedImage;
@property (nonatomic, strong) NSImage *pressedAlternateImage;
@property (nonatomic, strong) NSImage *disabledImage;
@property (nonatomic, strong) NSImage *disabledAlternateImage;

@property (nonatomic, strong) NSDictionary *baseAttributes;

@property (nonatomic, copy) void (^hoverBlock)(NPButtonCell *cell, BOOL hover);

@property (nonatomic, assign) CGFloat padding; // Padding between title and image (where appropriate)

@property (nonatomic, strong) id userData;

@property (nonatomic, readonly, getter=isHovering) BOOL hovering;

-(void)setImageWithImageMask:(NPImageMask*)imageMask;

@end
