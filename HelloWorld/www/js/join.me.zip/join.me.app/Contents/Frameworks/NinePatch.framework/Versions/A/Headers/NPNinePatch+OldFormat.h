//
//  NPNinePatch+OldFormat.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2012-10-01.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

#import <ninepatch/NPNinePatch.h>

#if TARGET_OS_MAC
@class NSImage;
#endif

// This category implements loading and saving nine part images from Google's 9patch format.
// This does not work well with retina images.  Please consider upgrading to the *.9p or *.9pi asset format.
@interface NPNinePatch (OldFormat)
+ (NPNinePatch *)ninePatchWithNinePatchCGImage:(CGImageRef)cgimage;
- (NSData *)PNGRepresentation;

#if TARGET_OS_MAC
+ (NPNinePatch *)ninePatchWithNinePatchImage:(NSImage *)image;
#endif
@end
