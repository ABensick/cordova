//
//  NPMenuDelegateProxy.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-15.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NPMenuDelegateProxy : NSProxy<NSMenuDelegate>
@property (nonatomic, assign) id<NSMenuDelegate> delegate;
- (id)init;
@end
