//
//  NPNinePatch+FlatFormat.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2012-10-01.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

#import <ninepatch/NPNinePatch.h>

// This category implements loading and saving nine part images from a custom flat binary format (*.9pi).
// This single-file format supports multi-resolution (1x & 2x) image variants.
@interface NPNinePatch (FlatFormat)
+ (NPNinePatch *)ninePatchFromFlatRepresentation:(NSData *)data;
- (NSData *)flatRepresentation;
@end

// 9PI File Format Specification
//
// All numerical fields are stored in little-endian format.
//
// Field            Length           Description
// ------------------------------------------------------------------------
// magic            4                "9PIF", constant
// version          4                constant 1
// flags            8                Bit 0: Horizontal tiling
//                                   Bit 1: Vertical tiling
//                                   Bit 2: Retina (2x) image is present
// center insets    4 * 4            top, left, bottom, right (in points)
// content insets   4 * 4            top, left, bottom, right (in points)
// mask insets      4 * 4            top, left, bottom, right (in points)
// image size @1x   8                in bytes
// image data @1x   ...              PNG format
// padding          0-7              the next field is aligned on an 8-byte boundary
// ------------------------------------------------------------------------
// image size @2x   8                in bytes (optional)
// image data @2x   ...              PNG format (optional)
// ------------------------------------------------------------------------
